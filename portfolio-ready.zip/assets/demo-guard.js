/**
 * DEMO SESSION GUARD
 * Include this at the very top of <body> in any gated demo app, after
 * defining:
 *   window.DEMO_GUARD_CONFIG = { apiBase: "...", project: "education-management" };
 *
 * What it does:
 *  - Blocks the page behind an overlay until the server confirms the
 *    session (?session=...) is valid.
 *  - Polls the server every few seconds for the real remaining time —
 *    the countdown shown here is cosmetic, the SERVER decides expiry.
 *  - On expiry (server-confirmed), blocks the page and redirects to
 *    demo-expired.html.
 *
 * Honest limitation: this app is a single static HTML file. This guard
 * controls *access and the UI*, but it cannot erase code the browser has
 * already downloaded — a visitor using devtools could inspect it after
 * the fact. It reliably stops normal use once the timer ends and stops
 * the page from ever loading without a valid, server-verified session.
 */
(function () {
  const cfg = window.DEMO_GUARD_CONFIG || {};
  const API_BASE = cfg.apiBase;
  const PROJECT = cfg.project;
  const sessionId = new URLSearchParams(location.search).get("session");

  function goExpired() {
    location.href = `../demo-expired.html?project=${encodeURIComponent(PROJECT)}`;
  }

  if (!sessionId) { goExpired(); return; }

  // ---- blocking overlay (shown until first server check resolves) ----
  const overlay = document.createElement("div");
  overlay.id = "demo-guard-overlay";
  overlay.style.cssText = "position:fixed;inset:0;background:#F4F7FE;z-index:99999;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:#3F55E0;font-weight:600;";
  overlay.textContent = "Checking your demo session…";
  document.documentElement.appendChild(overlay);

  // ---- floating "DEMO MODE" badge ----
  const badge = document.createElement("div");
  badge.id = "demo-mode-badge";
  badge.style.cssText = "position:fixed;bottom:16px;right:16px;z-index:99998;background:#1E2A45;color:#fff;font-family:sans-serif;font-size:12.5px;font-weight:600;padding:8px 14px;border-radius:999px;box-shadow:0 6px 18px rgba(30,42,69,.25);display:none;align-items:center;gap:8px;";
  badge.innerHTML = '<span style="width:7px;height:7px;border-radius:50%;background:#FF6B2B;display:inline-block;"></span> DEMO MODE &bull; <span id="demo-guard-time">--:--</span> REMAINING';
  document.documentElement.appendChild(badge);

  let secondsRemaining = null;
  let localTickHandle = null;

  function renderTime() {
    if (secondsRemaining == null) return;
    const m = String(Math.floor(secondsRemaining / 60)).padStart(2, "0");
    const s = String(secondsRemaining % 60).padStart(2, "0");
    const el = document.getElementById("demo-guard-time");
    if (el) el.textContent = `${m}:${s}`;
  }

  function startLocalTick() {
    clearInterval(localTickHandle);
    localTickHandle = setInterval(() => {
      if (secondsRemaining == null) return;
      secondsRemaining = Math.max(0, secondsRemaining - 1);
      renderTime();
    }, 1000);
  }

  async function checkSession() {
    try {
      const res = await fetch(`${API_BASE}/session/${sessionId}`);
      const data = await res.json();

      if (!data.valid) {
        goExpired();
        return;
      }

      // Resync the cosmetic timer to the server's authoritative value.
      secondsRemaining = data.secondsRemaining;
      renderTime();

      overlay.style.display = "none";
      badge.style.display = "flex";
      if (!localTickHandle) startLocalTick();
    } catch (e) {
      // Network hiccup — don't kick the user out over a single failed poll,
      // just try again on the next interval.
    }
  }

  checkSession();
  setInterval(checkSession, 5000); // server re-check every 5s = real enforcement
})();
